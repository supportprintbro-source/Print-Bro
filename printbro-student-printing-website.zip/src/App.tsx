import { useState } from "react";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import WhyPrintBro from "./components/WhyPrintBro";
import Pricing from "./components/Pricing";
import OrderForm from "./components/OrderForm";
import HowItWorks from "./components/HowItWorks";
import EmailFileSystem from "./components/EmailFileSystem";
import Delivery from "./components/Delivery";
import About from "./components/About";
import Contact from "./components/Contact";
import Footer from "./components/Footer";
import PrivacyModal from "./components/PrivacyModal";
import type { PrintType } from "./types/order";

export default function App() {
  const [presetType, setPresetType] = useState<PrintType | null>(null);
  const [privacyOpen, setPrivacyOpen] = useState(false);

  function handleSelectType(type: PrintType) {
    setPresetType(type);
    // Small timeout lets React apply the preset before the smooth scroll runs.
    requestAnimationFrame(() => {
      document.getElementById("order")?.scrollIntoView({ behavior: "smooth" });
    });
  }

  return (
    <div className="min-h-screen bg-white font-sans text-navy-900">
      <Navbar />
      <main>
        <Hero />
        <WhyPrintBro />
        <Pricing onSelectType={handleSelectType} />

        <section id="order" className="bg-navy-950/[0.02] px-5 py-20 sm:px-8 sm:py-28">
          <div className="mx-auto max-w-6xl">
            <div className="mx-auto max-w-2xl text-center">
              <span className="inline-block rounded-full bg-gold-400/20 px-4 py-1.5 text-xs font-bold uppercase tracking-wider text-navy-900">
                Order in minutes
              </span>
              <h2 className="mt-4 text-3xl font-extrabold tracking-tight text-navy-900 sm:text-4xl">
                Place Your Print Order
              </h2>
              <p className="mt-3 text-navy-700/70">
                Fill in your details, upload your file, and see your estimated price instantly.
              </p>
            </div>

            <div className="mt-12">
              <OrderForm presetType={presetType} />
            </div>
          </div>
        </section>

        <HowItWorks />
        <EmailFileSystem />
        <Delivery />
        <About />
        <Contact />
      </main>
      <Footer onOpenPrivacy={() => setPrivacyOpen(true)} />
      {privacyOpen && <PrivacyModal onClose={() => setPrivacyOpen(false)} />}
    </div>
  );
}
