import type { ReactNode } from "react";
import { CheckCircle2, MessageCircle, Mail, RotateCcw, MapPin, FileText } from "lucide-react";
import type { Order } from "../types/order";
import { PRINT_TYPE_LABELS } from "../types/order";
import { formatBDT } from "../lib/pricing";
import { CONFIG } from "../lib/config";

interface Props {
  order: Order;
  onReset: () => void;
}

function buildWhatsAppMessage(order: Order) {
  const lines = [
    `Hi PrintBro! I'd like to confirm my order.`,
    ``,
    `*Order ID:* ${order.id}`,
    `*Name:* ${order.customerName}`,
    `*Print Type:* ${PRINT_TYPE_LABELS[order.printType]}`,
    `*Pages:* ${order.pages}`,
    `*Copies:* ${order.copies}`,
    `*Estimated Total:* ${formatBDT(order.estimatedTotal)}`,
    `*Delivery Address:* ${order.address}`,
    order.file ? `*File:* ${order.file.name}` : `*File:* (will be emailed separately)`,
    order.notes ? `*Notes:* ${order.notes}` : ``,
  ].filter(Boolean);
  return lines.join("\n");
}

function buildEmailBody(order: Order) {
  return [
    `Hello PrintBro,`,
    ``,
    `Please find my file attached for the order below.`,
    ``,
    `Order ID: ${order.id}`,
    `Name: ${order.customerName}`,
    `Print Type: ${PRINT_TYPE_LABELS[order.printType]}`,
    `Pages: ${order.pages}`,
    `Copies: ${order.copies}`,
    `Estimated Total: ${formatBDT(order.estimatedTotal)}`,
    `Delivery Address: ${order.address}`,
    order.notes ? `Notes: ${order.notes}` : ``,
    ``,
    `Thank you!`,
  ]
    .filter(Boolean)
    .join("\n");
}

export default function OrderConfirmation({ order, onReset }: Props) {
  const whatsappHref = `https://wa.me/${CONFIG.whatsappNumber}?text=${encodeURIComponent(
    buildWhatsAppMessage(order)
  )}`;
  const emailHref = `mailto:${CONFIG.supportEmail}?subject=${encodeURIComponent(
    `PrintBro Order ${order.id} — File Attached`
  )}&body=${encodeURIComponent(buildEmailBody(order))}`;

  return (
    <div className="animate-in rounded-3xl bg-white p-6 shadow-2xl shadow-navy-900/10 ring-1 ring-navy-900/5 sm:p-10">
      <div className="flex flex-col items-center text-center">
        <div className="flex h-16 w-16 items-center justify-center rounded-full bg-emerald-100 text-emerald-600">
          <CheckCircle2 size={36} />
        </div>
        <h3 className="mt-5 text-2xl font-extrabold text-navy-900">
          Your order has been received successfully!
        </h3>
        <p className="mt-2 text-navy-700/70">
          Save your Order ID — you'll need it when confirming on WhatsApp.
        </p>
        <div className="mt-4 inline-flex items-center gap-2 rounded-full bg-navy-950 px-6 py-2.5">
          <span className="text-xs font-semibold uppercase text-white/60">Order ID</span>
          <span className="font-mono text-lg font-extrabold text-gold-400">{order.id}</span>
        </div>
      </div>

      <div className="mt-8 grid grid-cols-1 gap-4 rounded-2xl bg-navy-950/[0.03] p-5 sm:grid-cols-2 sm:p-6">
        <SummaryRow label="Customer Name" value={order.customerName} />
        <SummaryRow label="Mobile" value={order.mobile} />
        <SummaryRow label="Print Type" value={PRINT_TYPE_LABELS[order.printType]} />
        <SummaryRow label="Pages × Copies" value={`${order.pages} × ${order.copies}`} />
        <SummaryRow
          label="Uploaded File"
          value={order.file ? order.file.name : "Not attached — will be emailed"}
          icon={<FileText size={14} />}
        />
        <SummaryRow
          label="Delivery Address"
          value={order.address}
          icon={<MapPin size={14} />}
        />
        <div className="sm:col-span-2 mt-2 flex items-center justify-between rounded-xl bg-navy-900 px-5 py-4">
          <span className="text-sm font-semibold text-white/80">Estimated Price</span>
          <span className="text-2xl font-extrabold text-gold-400">
            {formatBDT(order.estimatedTotal)}
          </span>
        </div>
      </div>

      <p className="mt-5 text-center text-xs text-navy-700/50">
        {order.file
          ? "If your file wasn't attached automatically, please email it using the button below."
          : "Please email your document file so we can start printing."}
      </p>

      <div className="mt-6 grid grid-cols-1 gap-3 sm:grid-cols-3">
        <a
          href={whatsappHref}
          target="_blank"
          rel="noreferrer"
          className="inline-flex items-center justify-center gap-2 rounded-full bg-[#25D366] px-5 py-3.5 text-sm font-bold text-white shadow-lg shadow-[#25D366]/30 transition-all hover:-translate-y-0.5 hover:brightness-95"
        >
          <MessageCircle size={18} />
          Confirm Order on WhatsApp
        </a>
        <a
          href={emailHref}
          className="inline-flex items-center justify-center gap-2 rounded-full border border-navy-900/15 bg-white px-5 py-3.5 text-sm font-bold text-navy-900 transition-all hover:-translate-y-0.5 hover:bg-navy-950/[0.04]"
        >
          <Mail size={18} />
          Email Your File
        </a>
        <button
          onClick={onReset}
          className="inline-flex items-center justify-center gap-2 rounded-full bg-navy-950/[0.05] px-5 py-3.5 text-sm font-bold text-navy-800 transition-all hover:-translate-y-0.5 hover:bg-navy-950/[0.1]"
        >
          <RotateCcw size={18} />
          Place Another Order
        </button>
      </div>
    </div>
  );
}

function SummaryRow({
  label,
  value,
  icon,
}: {
  label: string;
  value: string;
  icon?: ReactNode;
}) {
  return (
    <div>
      <p className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-navy-700/50">
        {icon}
        {label}
      </p>
      <p className="mt-1 break-words text-sm font-bold text-navy-900">{value}</p>
    </div>
  );
}
