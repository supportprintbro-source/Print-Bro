import { useState } from "react";
import { FileEdit, Mail, MessageCircle, PartyPopper, Copy, Check } from "lucide-react";
import { CONFIG } from "../lib/config";

const STEPS = [
  {
    icon: FileEdit,
    number: "1",
    title: "Fill the Form",
    desc: "Choose your print type, pages and details in our order form.",
  },
  {
    icon: Mail,
    number: "2",
    title: "Email Your File",
    desc: "Send your PDF/DOCX file to us if it isn't attached directly.",
  },
  {
    icon: MessageCircle,
    number: "3",
    title: "Confirm on WhatsApp",
    desc: "Send your order summary and Order ID to us on WhatsApp.",
  },
  {
    icon: PartyPopper,
    number: "4",
    title: "Done!",
    desc: "We print your documents and deliver them straight to you.",
  },
];

export default function EmailFileSystem() {
  const [copied, setCopied] = useState(false);

  async function copyEmail() {
    try {
      await navigator.clipboard.writeText(CONFIG.supportEmail);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Clipboard API unavailable — ignore silently.
    }
  }

  return (
    <section className="bg-white px-5 py-20 sm:px-8 sm:py-28">
      <div className="mx-auto max-w-6xl">
        <div className="grid grid-cols-1 gap-12 lg:grid-cols-[1fr_1.1fr] lg:items-center">
          <div>
            <span className="inline-block rounded-full bg-gold-400/20 px-4 py-1.5 text-xs font-bold uppercase tracking-wider text-navy-900">
              Simple workflow
            </span>
            <h2 className="mt-4 text-3xl font-extrabold tracking-tight text-navy-900 sm:text-4xl">
              Fill the Form → Email Your File → Confirm on WhatsApp → Done!
            </h2>
            <p className="mt-4 text-navy-700/70">
              Can't attach your file directly in the order form? No problem. Send it straight to
              our support inbox and we'll match it to your Order ID.
            </p>

            <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-center">
              <div className="flex items-center gap-2 rounded-2xl border border-navy-900/10 bg-navy-950/[0.03] px-4 py-3">
                <Mail size={18} className="text-royal-600" />
                <a
                  href={`mailto:${CONFIG.supportEmail}`}
                  className="text-sm font-bold text-navy-900 hover:text-royal-600"
                >
                  {CONFIG.supportEmail}
                </a>
              </div>
              <button
                onClick={copyEmail}
                className="inline-flex items-center justify-center gap-2 rounded-full border border-navy-900/15 px-4 py-2.5 text-xs font-bold text-navy-800 transition-colors hover:bg-navy-950/[0.04]"
              >
                {copied ? <Check size={14} className="text-emerald-600" /> : <Copy size={14} />}
                {copied ? "Copied!" : "Copy Email"}
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            {STEPS.map(({ icon: Icon, number, title, desc }) => (
              <div
                key={title}
                className="group rounded-2xl border border-navy-900/10 bg-white p-5 shadow-sm transition-all hover:-translate-y-1 hover:shadow-lg"
              >
                <div className="flex items-center gap-3">
                  <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-royal-600/10 text-royal-600 transition-colors group-hover:bg-royal-600 group-hover:text-white">
                    <Icon size={20} />
                  </div>
                  <span className="text-2xl font-extrabold text-navy-900/10">{number}</span>
                </div>
                <h3 className="mt-3 text-sm font-extrabold text-navy-900">{title}</h3>
                <p className="mt-1 text-xs leading-relaxed text-navy-700/60">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
