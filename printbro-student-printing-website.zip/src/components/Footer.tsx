import { Mail, GraduationCap } from "lucide-react";
import Logo from "./Logo";
import { CONFIG } from "../lib/config";

interface FooterProps {
  onOpenPrivacy: () => void;
}

const LINKS = [
  { label: "Home", href: "#home" },
  { label: "Pricing", href: "#pricing" },
  { label: "How It Works", href: "#how-it-works" },
  { label: "Order", href: "#order" },
  { label: "Contact", href: "#contact" },
];

export default function Footer({ onOpenPrivacy }: FooterProps) {
  return (
    <footer className="bg-navy-950 px-5 pb-8 pt-16 sm:px-8">
      <div className="mx-auto max-w-6xl">
        <div className="grid grid-cols-1 gap-10 border-b border-white/10 pb-10 sm:grid-cols-3">
          <div>
            <Logo variant="light" />
            <p className="mt-4 max-w-xs text-sm text-white/60">
              Smart Printing for Smart Students. Fast, affordable and reliable document printing —
              built for campus life.
            </p>
          </div>

          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-gold-400">
              Quick Links
            </h4>
            <ul className="mt-4 space-y-2.5">
              {LINKS.map((l) => (
                <li key={l.href}>
                  <a href={l.href} className="text-sm text-white/70 hover:text-white">
                    {l.label}
                  </a>
                </li>
              ))}
              <li>
                <button
                  onClick={onOpenPrivacy}
                  className="text-sm text-white/70 hover:text-white"
                >
                  Privacy Policy
                </button>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-gold-400">
              Contact
            </h4>
            <a
              href={`mailto:${CONFIG.supportEmail}`}
              className="mt-4 flex items-center gap-2 text-sm text-white/70 hover:text-white"
            >
              <Mail size={16} />
              {CONFIG.supportEmail}
            </a>
            <p className="mt-4 flex items-center gap-2 text-xs text-white/40">
              <GraduationCap size={14} />
              Built by students, for students.
            </p>
          </div>
        </div>

        <div className="flex flex-col items-center justify-between gap-3 pt-6 text-center sm:flex-row sm:text-left">
          <p className="text-xs text-white/50">
            © {new Date().getFullYear()} PrintBro. All rights reserved.
          </p>
          <p className="text-xs font-semibold text-gold-400">
            Made for Students. By Students.
          </p>
        </div>
      </div>
    </footer>
  );
}
