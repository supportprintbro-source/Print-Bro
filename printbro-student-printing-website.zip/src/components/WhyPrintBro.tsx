import { Rocket, ShieldCheck, Wallet, Lock } from "lucide-react";

const FEATURES = [
  {
    icon: Rocket,
    title: "Fast",
    desc: "Quick & On-Time",
  },
  {
    icon: ShieldCheck,
    title: "Reliable",
    desc: "Quality You Can Trust",
  },
  {
    icon: Wallet,
    title: "Affordable",
    desc: "Student Friendly",
  },
  {
    icon: Lock,
    title: "Secure",
    desc: "Your Privacy Matters",
  },
];

export default function WhyPrintBro() {
  return (
    <section className="relative -mt-10 px-5 sm:-mt-14 sm:px-8">
      <div className="mx-auto max-w-6xl rounded-3xl bg-white p-6 shadow-2xl shadow-navy-900/10 ring-1 ring-navy-900/5 sm:p-8">
        <div className="grid grid-cols-2 gap-6 sm:gap-4 lg:grid-cols-4">
          {FEATURES.map(({ icon: Icon, title, desc }, i) => (
            <div
              key={title}
              className="group flex flex-col items-center gap-3 rounded-2xl px-3 py-5 text-center transition-all duration-300 hover:-translate-y-1 hover:bg-navy-950/[0.03] sm:flex-row sm:text-left"
              style={{ animationDelay: `${i * 80}ms` }}
            >
              <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-royal-600/10 text-royal-600 transition-colors group-hover:bg-royal-600 group-hover:text-white">
                <Icon size={26} strokeWidth={2} />
              </div>
              <div>
                <p className="text-base font-extrabold text-navy-900">{title}</p>
                <p className="text-sm text-navy-700/70">{desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
