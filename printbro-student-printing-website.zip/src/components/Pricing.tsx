import { FileText, Files, Palette, ArrowRight } from "lucide-react";
import type { PrintType } from "../types/order";

interface PricingProps {
  onSelectType: (type: PrintType) => void;
}

const PLANS: {
  type: PrintType;
  badge: string;
  badgeClass: string;
  title: string;
  icon: typeof FileText;
  rows: { label: string; price: string }[];
  note: string;
  accent: string;
}[] = [
  {
    type: "bw-single",
    badge: "BLACK & WHITE",
    badgeClass: "bg-navy-900 text-white",
    title: "Single Sided",
    icon: FileText,
    rows: [
      { label: "1–100 pages", price: "৳3.00" },
      { label: "100+ pages", price: "৳2.50" },
    ],
    note: "per page",
    accent: "from-navy-900 to-royal-600",
  },
  {
    type: "bw-double",
    badge: "BLACK & WHITE",
    badgeClass: "bg-navy-900 text-white",
    title: "Both Sides",
    icon: Files,
    rows: [
      { label: "1–100 pages", price: "৳4.00" },
      { label: "100+ pages", price: "৳3.00" },
    ],
    note: "per page",
    accent: "from-royal-600 to-royal-400",
  },
  {
    type: "color-single",
    badge: "FULL COLOUR",
    badgeClass: "bg-gradient-to-r from-royal-500 via-fuchsia-500 to-gold-400 text-white",
    title: "Single Sided",
    icon: Palette,
    rows: [{ label: "All pages", price: "৳4.00" }],
    note: "per page",
    accent: "from-gold-500 to-gold-300",
  },
];

export default function Pricing({ onSelectType }: PricingProps) {
  return (
    <section id="pricing" className="bg-white px-5 py-20 sm:px-8 sm:py-28">
      <div className="mx-auto max-w-6xl">
        <div className="mx-auto max-w-2xl text-center">
          <span className="inline-block rounded-full bg-royal-600/10 px-4 py-1.5 text-xs font-bold uppercase tracking-wider text-royal-600">
            Simple, transparent pricing
          </span>
          <h2 className="mt-4 text-3xl font-extrabold tracking-tight text-navy-900 sm:text-4xl">
            Choose Your Print Type
          </h2>
          <p className="mt-3 text-navy-700/70">
            Prices are calculated <span className="font-semibold text-navy-900">per printed page</span>.
            Pick a print type below to see your estimate instantly on the order form.
          </p>
        </div>

        <div className="mt-14 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {PLANS.map(({ type, badge, badgeClass, title, icon: Icon, rows, note, accent }) => (
            <div
              key={type}
              className="group relative flex flex-col rounded-3xl border border-navy-900/10 bg-white p-7 shadow-lg shadow-navy-900/5 transition-all duration-300 hover:-translate-y-1.5 hover:shadow-2xl hover:shadow-royal-600/10"
            >
              <div className={`absolute -top-3 left-7 rounded-full px-3 py-1 text-[11px] font-extrabold tracking-wide ${badgeClass}`}>
                {badge}
              </div>

              <div
                className={`mb-5 mt-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br ${accent} text-white shadow-md`}
              >
                <Icon size={26} />
              </div>

              <h3 className="text-xl font-extrabold text-navy-900">{title}</h3>

              <div className="mt-5 flex-1 space-y-3">
                {rows.map((r) => (
                  <div
                    key={r.label}
                    className="flex items-center justify-between rounded-xl bg-navy-950/[0.03] px-4 py-3"
                  >
                    <span className="text-sm font-medium text-navy-700/80">{r.label}</span>
                    <span className="text-base font-extrabold text-royal-600">
                      {r.price}
                      <span className="ml-1 text-xs font-medium text-navy-700/50">/page</span>
                    </span>
                  </div>
                ))}
              </div>

              <p className="mt-4 text-xs text-navy-700/50">
                Calculated {note} × number of copies. Bulk discount applies automatically.
              </p>

              <button
                onClick={() => onSelectType(type)}
                className="mt-6 inline-flex items-center justify-center gap-2 rounded-full bg-navy-900 px-5 py-3 text-sm font-bold text-white transition-all hover:bg-royal-600"
              >
                Select &amp; Order
                <ArrowRight size={16} />
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
