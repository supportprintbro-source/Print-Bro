interface LogoProps {
  variant?: "dark" | "light";
  showTagline?: boolean;
  className?: string;
}

/**
 * PrintBro brand mark — a stylised "P" built from a flag-like loop with
 * speed/page lines, echoing the uploaded logo & poster artwork.
 */
export default function Logo({
  variant = "dark",
  showTagline = false,
  className = "",
}: LogoProps) {
  const textPrimary = variant === "dark" ? "text-navy-900" : "text-white";
  const textAccent = variant === "dark" ? "text-royal-600" : "text-gold-400";
  const tagline = variant === "dark" ? "text-navy-700/70" : "text-white/70";

  return (
    <div className={`flex items-center gap-2.5 ${className}`}>
      <svg
        width="40"
        height="40"
        viewBox="0 0 64 64"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="shrink-0 drop-shadow-sm"
        aria-hidden="true"
      >
        <defs>
          <linearGradient id="pbGradient" x1="4" y1="4" x2="56" y2="60" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#152a63" />
            <stop offset="100%" stopColor="#2b52f0" />
          </linearGradient>
        </defs>
        <rect x="6" y="6" width="11" height="52" rx="5.5" fill="url(#pbGradient)" />
        <path
          d="M17 6 H36 C46.4934 6 55 14.5066 55 25 C55 35.4934 46.4934 44 36 44 H17 V33 H35 C39.9706 33 44 28.9706 44 24 C44 19.0294 39.9706 15 35 15 H17 V6 Z"
          fill="url(#pbGradient)"
        />
        <rect x="24" y="20" width="14" height="3.2" rx="1.6" fill="white" opacity="0.85" transform="skewX(-18)" />
        <rect x="24" y="26" width="10" height="3.2" rx="1.6" fill="white" opacity="0.6" transform="skewX(-18)" />
      </svg>
      <div className="leading-none">
        <div className={`text-2xl font-extrabold tracking-tight ${textPrimary}`}>
          Print<span className={textAccent}>Bro</span>
        </div>
        {showTagline && (
          <div className={`mt-0.5 text-[11px] font-medium italic ${tagline}`}>
            Smart Printing for Smart Students.
          </div>
        )}
      </div>
    </div>
  );
}
