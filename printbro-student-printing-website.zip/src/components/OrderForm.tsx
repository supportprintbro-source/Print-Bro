import { useEffect, useRef, useState } from "react";
import type { ReactNode } from "react";
import {
  UploadCloud,
  FileText,
  X,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  Loader2,
} from "lucide-react";
import type { Order, PrintType } from "../types/order";
import { PRINT_TYPE_LABELS } from "../types/order";
import { calculateEstimate, formatBDT } from "../lib/pricing";
import { validateFile, formatFileSize } from "../lib/fileValidation";
import { generateOrderId } from "../lib/orderId";
import { CONFIG } from "../lib/config";
import OrderConfirmation from "./OrderConfirmation";

interface OrderFormProps {
  presetType?: PrintType | null;
}

type StepId = "form" | "review" | "done";

interface FormState {
  customerName: string;
  mobile: string;
  email: string;
  address: string;
  printType: PrintType;
  pages: string;
  copies: string;
  notes: string;
}

const INITIAL_STATE: FormState = {
  customerName: "",
  mobile: "",
  email: "",
  address: "",
  printType: "bw-single",
  pages: "",
  copies: "1",
  notes: "",
};

export default function OrderForm({ presetType }: OrderFormProps) {
  const [step, setStep] = useState<StepId>("form");
  const [data, setData] = useState<FormState>(INITIAL_STATE);
  const [file, setFile] = useState<File | null>(null);
  const [fileError, setFileError] = useState<string | null>(null);
  const [errors, setErrors] = useState<Partial<Record<keyof FormState, string>>>({});
  const [submitting, setSubmitting] = useState(false);
  const [order, setOrder] = useState<Order | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (presetType) {
      setData((d) => ({ ...d, printType: presetType }));
    }
  }, [presetType]);

  const pagesNum = parseInt(data.pages, 10) || 0;
  const copiesNum = parseInt(data.copies, 10) || 0;
  const estimate = calculateEstimate(data.printType, pagesNum, copiesNum);

  function update<K extends keyof FormState>(key: K, value: FormState[K]) {
    setData((d) => ({ ...d, [key]: value }));
    setErrors((e) => ({ ...e, [key]: undefined }));
  }

  function handleFileSelect(selected: File | null) {
    if (!selected) return;
    const result = validateFile(selected);
    if (!result.valid) {
      setFileError(result.error ?? "Invalid file.");
      setFile(null);
      return;
    }
    setFileError(null);
    setFile(selected);
  }

  function validate(): boolean {
    const nextErrors: Partial<Record<keyof FormState, string>> = {};
    if (!data.customerName.trim()) nextErrors.customerName = "Please enter your name.";
    if (!/^[\d+\s-]{7,15}$/.test(data.mobile.trim()))
      nextErrors.mobile = "Please enter a valid mobile number.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email.trim()))
      nextErrors.email = "Please enter a valid email address.";
    if (!data.address.trim()) nextErrors.address = "Please enter a delivery address.";
    if (!pagesNum || pagesNum <= 0) nextErrors.pages = "Enter number of pages.";
    if (!copiesNum || copiesNum <= 0) nextErrors.copies = "Enter number of copies.";

    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  }

  function goToReview(e: React.FormEvent) {
    e.preventDefault();
    if (validate()) setStep("review");
  }

  async function confirmOrder() {
    setSubmitting(true);
    // Simulated network delay — replace with a real Supabase insert +
    // storage upload when the backend is connected (see lib/supabaseClient.ts)
    await new Promise((r) => setTimeout(r, 700));

    const newOrder: Order = {
      id: generateOrderId(),
      createdAt: new Date().toISOString(),
      customerName: data.customerName.trim(),
      mobile: data.mobile.trim(),
      email: data.email.trim(),
      address: data.address.trim(),
      printType: data.printType,
      pages: pagesNum,
      copies: copiesNum,
      notes: data.notes.trim() || undefined,
      file: file
        ? { name: file.name, sizeKB: Math.round(file.size / 1024), type: file.type }
        : undefined,
      ratePerPage: estimate.ratePerPage,
      estimatedTotal: estimate.total,
      status: "Pending",
    };

    setOrder(newOrder);
    setSubmitting(false);
    setStep("done");
  }

  function resetAll() {
    setData(INITIAL_STATE);
    setFile(null);
    setFileError(null);
    setErrors({});
    setOrder(null);
    setStep("form");
  }

  if (step === "done" && order) {
    return <OrderConfirmation order={order} onReset={resetAll} />;
  }

  return (
    <div className="grid grid-cols-1 gap-8 lg:grid-cols-5">
      {/* Form column */}
      <div className="lg:col-span-3">
        <div className="rounded-3xl bg-white p-6 shadow-2xl shadow-navy-900/10 ring-1 ring-navy-900/5 sm:p-8">
          {/* Step indicator */}
          <div className="mb-7 flex items-center gap-3">
            <StepDot active={step === "form"} done={step === "review"} label="1" />
            <div className="h-0.5 flex-1 bg-navy-900/10" />
            <StepDot active={step === "review"} done={false} label="2" />
          </div>

          {step === "form" && (
            <form onSubmit={goToReview} className="space-y-5" noValidate>
              <h3 className="text-xl font-extrabold text-navy-900">
                Step 1 — Your Details &amp; File
              </h3>

              <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                <Field label="Customer Name" error={errors.customerName}>
                  <input
                    type="text"
                    value={data.customerName}
                    onChange={(e) => update("customerName", e.target.value)}
                    placeholder="e.g. Ayesha Rahman"
                    className={inputClass(!!errors.customerName)}
                  />
                </Field>
                <Field label="Mobile Number" error={errors.mobile}>
                  <input
                    type="tel"
                    value={data.mobile}
                    onChange={(e) => update("mobile", e.target.value)}
                    placeholder="01XXXXXXXXX"
                    className={inputClass(!!errors.mobile)}
                  />
                </Field>
              </div>

              <Field label="Email Address" error={errors.email}>
                <input
                  type="email"
                  value={data.email}
                  onChange={(e) => update("email", e.target.value)}
                  placeholder="you@example.com"
                  className={inputClass(!!errors.email)}
                />
              </Field>

              <Field label="Delivery Address" error={errors.address}>
                <textarea
                  value={data.address}
                  onChange={(e) => update("address", e.target.value)}
                  placeholder="Hall / Dorm / Department, University, Area"
                  rows={2}
                  className={inputClass(!!errors.address)}
                />
              </Field>

              <Field label="Print Type">
                <select
                  value={data.printType}
                  onChange={(e) => update("printType", e.target.value as PrintType)}
                  className={inputClass(false)}
                >
                  {(Object.keys(PRINT_TYPE_LABELS) as PrintType[]).map((key) => (
                    <option key={key} value={key}>
                      {PRINT_TYPE_LABELS[key]}
                    </option>
                  ))}
                </select>
              </Field>

              <div className="grid grid-cols-2 gap-5">
                <Field label="Number of Pages" error={errors.pages}>
                  <input
                    type="number"
                    min={1}
                    value={data.pages}
                    onChange={(e) => update("pages", e.target.value)}
                    placeholder="e.g. 40"
                    className={inputClass(!!errors.pages)}
                  />
                </Field>
                <Field label="Number of Copies" error={errors.copies}>
                  <input
                    type="number"
                    min={1}
                    value={data.copies}
                    onChange={(e) => update("copies", e.target.value)}
                    className={inputClass(!!errors.copies)}
                  />
                </Field>
              </div>

              <Field label="Optional Notes / Instructions">
                <textarea
                  value={data.notes}
                  onChange={(e) => update("notes", e.target.value)}
                  placeholder="e.g. Please staple pages, print in booklet form, etc."
                  rows={2}
                  className={inputClass(false)}
                />
              </Field>

              {/* File upload */}
              <div>
                <label className="mb-1.5 block text-sm font-semibold text-navy-900">
                  Upload File{" "}
                  <span className="font-normal text-navy-700/50">(PDF, DOCX, PPT/PPTX)</span>
                </label>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept={CONFIG.allowedFileTypes.join(",")}
                  className="hidden"
                  onChange={(e) => handleFileSelect(e.target.files?.[0] ?? null)}
                />
                {!file ? (
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="flex w-full flex-col items-center gap-2 rounded-2xl border-2 border-dashed border-navy-900/20 bg-navy-950/[0.02] px-5 py-8 text-center transition-colors hover:border-royal-500 hover:bg-royal-500/5"
                  >
                    <UploadCloud size={28} className="text-royal-600" />
                    <span className="text-sm font-semibold text-navy-900">
                      Click to upload your document
                    </span>
                    <span className="text-xs text-navy-700/50">
                      Max {CONFIG.maxFileSizeMB}MB · {CONFIG.allowedFileTypes.join(", ")}
                    </span>
                  </button>
                ) : (
                  <div className="flex items-center justify-between rounded-2xl border border-navy-900/10 bg-navy-950/[0.03] px-4 py-3.5">
                    <div className="flex items-center gap-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-royal-600/10 text-royal-600">
                        <FileText size={20} />
                      </div>
                      <div>
                        <p className="max-w-[180px] truncate text-sm font-bold text-navy-900 sm:max-w-xs">
                          {file.name}
                        </p>
                        <p className="text-xs text-navy-700/50">{formatFileSize(file.size)}</p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setFile(null);
                        if (fileInputRef.current) fileInputRef.current.value = "";
                      }}
                      className="flex h-8 w-8 items-center justify-center rounded-full text-navy-700/50 hover:bg-red-50 hover:text-red-500"
                      aria-label="Remove file"
                    >
                      <X size={16} />
                    </button>
                  </div>
                )}
                {fileError && <p className="mt-1.5 text-xs font-medium text-red-500">{fileError}</p>}
                <p className="mt-1.5 text-xs text-navy-700/40">
                  Can't attach here? No problem — you can email your file after placing the order.
                </p>
              </div>

              <button
                type="submit"
                className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-royal-600 px-6 py-3.5 text-sm font-bold text-white shadow-lg shadow-royal-600/25 transition-all hover:-translate-y-0.5 hover:bg-navy-900"
              >
                Review Order
                <ArrowRight size={18} />
              </button>
            </form>
          )}

          {step === "review" && (
            <div className="space-y-5">
              <h3 className="text-xl font-extrabold text-navy-900">Step 2 — Review &amp; Confirm</h3>
              <div className="grid grid-cols-1 gap-3 rounded-2xl bg-navy-950/[0.03] p-5 sm:grid-cols-2">
                <ReviewItem label="Name" value={data.customerName} />
                <ReviewItem label="Mobile" value={data.mobile} />
                <ReviewItem label="Email" value={data.email} />
                <ReviewItem label="Print Type" value={PRINT_TYPE_LABELS[data.printType]} />
                <ReviewItem label="Pages" value={String(pagesNum)} />
                <ReviewItem label="Copies" value={String(copiesNum)} />
                <ReviewItem label="Address" value={data.address} full />
                {data.notes && <ReviewItem label="Notes" value={data.notes} full />}
                <ReviewItem label="File" value={file ? file.name : "Not attached (will email)"} full />
              </div>

              <div className="flex flex-col gap-3 sm:flex-row">
                <button
                  onClick={() => setStep("form")}
                  className="inline-flex items-center justify-center gap-2 rounded-full border border-navy-900/15 px-6 py-3.5 text-sm font-bold text-navy-900 transition-all hover:bg-navy-950/[0.04] sm:w-auto"
                >
                  <ArrowLeft size={18} />
                  Edit Details
                </button>
                <button
                  onClick={confirmOrder}
                  disabled={submitting}
                  className="inline-flex flex-1 items-center justify-center gap-2 rounded-full bg-gold-400 px-6 py-3.5 text-sm font-bold text-navy-950 shadow-lg shadow-gold-400/30 transition-all hover:-translate-y-0.5 hover:bg-gold-300 disabled:opacity-70"
                >
                  {submitting ? (
                    <>
                      <Loader2 size={18} className="animate-spin" />
                      Placing Order...
                    </>
                  ) : (
                    <>
                      <CheckCircle2 size={18} />
                      Submit Order
                    </>
                  )}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Live estimate column */}
      <div className="lg:col-span-2">
        <div className="sticky top-24 rounded-3xl bg-gradient-to-br from-navy-950 to-royal-600 p-7 text-white shadow-2xl shadow-navy-900/20">
          <p className="text-xs font-bold uppercase tracking-wider text-gold-400">
            Estimated Price
          </p>
          <p className="mt-2 text-4xl font-extrabold tracking-tight">
            {formatBDT(estimate.total)}
          </p>
          <p className="mt-1 text-sm text-white/60">Updates instantly as you type</p>

          <div className="mt-6 space-y-3 border-t border-white/10 pt-5 text-sm">
            <Row label="Print Type" value={PRINT_TYPE_LABELS[data.printType]} />
            <Row label="Rate / Page" value={formatBDT(estimate.ratePerPage)} />
            <Row label="Pages" value={String(pagesNum || 0)} />
            <Row label="Copies" value={String(copiesNum || 0)} />
            <Row label="Total Printed Pages" value={String(estimate.totalPrintedPages)} />
          </div>

          <div className="mt-6 rounded-2xl bg-white/10 p-4 text-xs leading-relaxed text-white/70">
            Bulk pricing applies automatically for documents over 100 pages. Final price is
            confirmed on WhatsApp before printing begins.
          </div>
        </div>
      </div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-white/60">{label}</span>
      <span className="font-semibold">{value}</span>
    </div>
  );
}

function ReviewItem({ label, value, full }: { label: string; value: string; full?: boolean }) {
  return (
    <div className={full ? "sm:col-span-2" : ""}>
      <p className="text-xs font-semibold uppercase tracking-wide text-navy-700/50">{label}</p>
      <p className="mt-0.5 break-words text-sm font-bold text-navy-900">{value}</p>
    </div>
  );
}

function Field({
  label,
  error,
  children,
}: {
  label: string;
  error?: string;
  children: ReactNode;
}) {
  return (
    <div>
      <label className="mb-1.5 block text-sm font-semibold text-navy-900">{label}</label>
      {children}
      {error && <p className="mt-1 text-xs font-medium text-red-500">{error}</p>}
    </div>
  );
}

function inputClass(hasError: boolean) {
  return `w-full rounded-xl border px-4 py-2.5 text-sm text-navy-900 outline-none transition-colors placeholder:text-navy-700/30 focus:ring-2 ${
    hasError
      ? "border-red-400 focus:ring-red-200"
      : "border-navy-900/15 focus:border-royal-500 focus:ring-royal-500/20"
  }`;
}

function StepDot({ active, done, label }: { active: boolean; done: boolean; label: string }) {
  return (
    <div
      className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-sm font-bold transition-colors ${
        active
          ? "bg-royal-600 text-white"
          : done
          ? "bg-emerald-500 text-white"
          : "bg-navy-900/10 text-navy-700/50"
      }`}
    >
      {done ? <CheckCircle2 size={18} /> : label}
    </div>
  );
}
