import { GraduationCap, ArrowRight, PlayCircle } from "lucide-react";

export default function Hero() {
  return (
    <section
      id="home"
      className="relative overflow-hidden bg-gradient-to-br from-navy-950 via-navy-900 to-royal-600 pb-20 pt-32 sm:pb-28 sm:pt-40"
    >
      {/* Decorative background shapes */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute -left-24 top-10 h-72 w-72 rounded-full bg-royal-500/30 blur-3xl" />
        <div className="absolute -right-16 bottom-0 h-96 w-96 rounded-full bg-gold-400/10 blur-3xl" />
        <svg
          className="absolute right-0 top-0 h-full w-1/2 opacity-20"
          viewBox="0 0 400 400"
          fill="none"
        >
          <circle cx="380" cy="40" r="200" stroke="white" strokeWidth="1" />
          <circle cx="380" cy="40" r="140" stroke="white" strokeWidth="1" />
        </svg>
      </div>

      <div className="relative mx-auto grid max-w-7xl grid-cols-1 items-center gap-14 px-5 sm:px-8 lg:grid-cols-2 lg:gap-10">
        {/* Left column */}
        <div className="animate-in">
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-gold-400/40 bg-white/5 px-4 py-2 backdrop-blur-sm">
            <GraduationCap size={16} className="text-gold-400" />
            <span className="text-xs font-bold tracking-wide text-white">
              Made for <span className="text-gold-400">Students</span> By Students
            </span>
          </div>

          <h1 className="text-4xl font-extrabold leading-[1.08] tracking-tight text-white sm:text-5xl lg:text-6xl">
            Print Smart.
            <br />
            Save Time.
            <br />
            Focus on <span className="text-gold-400">Success.</span>
          </h1>

          <p className="mt-6 max-w-lg border-l-4 border-gold-400 pl-4 text-lg text-white/85">
            Fast. Reliable. Student-friendly.
            <br />
            Your documents, printed the <span className="font-semibold text-white">smart</span> way.
          </p>

          <div className="mt-9 flex flex-wrap items-center gap-4">
            <a
              href="#order"
              className="group inline-flex items-center gap-2 rounded-full bg-gold-400 px-7 py-3.5 text-sm font-bold text-navy-950 shadow-lg shadow-gold-400/30 transition-all hover:-translate-y-0.5 hover:bg-gold-300 hover:shadow-xl"
            >
              Order Now
              <ArrowRight size={18} className="transition-transform group-hover:translate-x-1" />
            </a>
            <a
              href="#how-it-works"
              className="inline-flex items-center gap-2 rounded-full border border-white/30 bg-white/5 px-7 py-3.5 text-sm font-bold text-white backdrop-blur-sm transition-all hover:-translate-y-0.5 hover:bg-white/15"
            >
              <PlayCircle size={18} />
              How It Works
            </a>
          </div>

          <div className="mt-10 inline-flex items-center gap-3 rounded-2xl bg-white/10 px-5 py-3 backdrop-blur-sm">
            <span className="text-xs font-semibold uppercase tracking-wide text-white/70">
              Starting from
            </span>
            <span className="text-2xl font-extrabold text-gold-400">৳2.50</span>
            <span className="text-sm font-medium text-white/70">/page</span>
          </div>
        </div>

        {/* Right column — visual */}
        <div className="relative animate-in [animation-delay:150ms]">
          <div className="relative mx-auto max-w-md">
            <div className="absolute -inset-6 rounded-[2.5rem] bg-white/5 backdrop-blur-sm" />
            <img
              src="/images/hero-printer.png"
              alt="A printer producing PrintBro documents for students"
              className="relative z-10 w-full rounded-3xl animate-float"
            />
            <div className="absolute -left-4 bottom-6 z-20 rounded-2xl bg-white px-4 py-3 shadow-xl sm:-left-8">
              <p className="text-xs font-semibold text-navy-700/70">Delivery Ready</p>
              <p className="text-sm font-bold text-navy-900">On-Time, Every Time</p>
            </div>
            <div className="absolute -right-2 top-6 z-20 rounded-2xl bg-navy-900 px-4 py-3 shadow-xl sm:-right-6">
              <p className="text-xs font-semibold text-gold-400">Trusted by</p>
              <p className="text-sm font-bold text-white">1000+ Students</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
