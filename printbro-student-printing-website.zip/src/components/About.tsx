import { GraduationCap, Heart, Target } from "lucide-react";

export default function About() {
  return (
    <section className="bg-white px-5 py-20 sm:px-8 sm:py-28">
      <div className="mx-auto max-w-4xl text-center">
        <span className="inline-flex items-center gap-2 rounded-full bg-royal-600/10 px-4 py-1.5 text-xs font-bold uppercase tracking-wider text-royal-600">
          <GraduationCap size={14} />
          About PrintBro
        </span>
        <h2 className="mt-4 text-3xl font-extrabold tracking-tight text-navy-900 sm:text-4xl">
          Made for Students, By Students
        </h2>
        <p className="mx-auto mt-5 max-w-2xl text-navy-700/70">
          PrintBro was built by students who understand the last-minute rush of assignments,
          reports and presentations. We designed a simple, transparent and affordable printing
          service so university and college students can order documents online, upload their
          files in minutes, and get accurate prints delivered — without wasting time standing in
          line at a print shop.
        </p>

        <div className="mt-10 grid grid-cols-1 gap-5 sm:grid-cols-2">
          <div className="flex items-start gap-3 rounded-2xl border border-navy-900/10 p-5 text-left">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gold-400/20 text-navy-900">
              <Target size={20} />
            </div>
            <div>
              <h3 className="text-sm font-extrabold text-navy-900">Our Mission</h3>
              <p className="mt-1 text-sm text-navy-700/60">
                Make academic printing faster, more affordable, and stress-free for every student.
              </p>
            </div>
          </div>
          <div className="flex items-start gap-3 rounded-2xl border border-navy-900/10 p-5 text-left">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gold-400/20 text-navy-900">
              <Heart size={20} />
            </div>
            <div>
              <h3 className="text-sm font-extrabold text-navy-900">Built With Care</h3>
              <p className="mt-1 text-sm text-navy-700/60">
                Every feature is designed around what students actually need — clarity, speed and
                fair pricing.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
