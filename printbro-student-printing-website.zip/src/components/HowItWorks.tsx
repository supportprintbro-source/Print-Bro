import { FileEdit, Mail, MessageCircle, Printer } from "lucide-react";

const STEPS = [
  {
    icon: FileEdit,
    title: "Fill the Form",
    desc: "Choose your print type, pages and delivery details.",
  },
  {
    icon: Mail,
    title: "Email Your File",
    desc: "Send your PDF / DOCX / PPT file to our support email.",
  },
  {
    icon: MessageCircle,
    title: "Confirm on WhatsApp",
    desc: "Send your order summary to us for final confirmation.",
  },
  {
    icon: Printer,
    title: "Done!",
    desc: "We print and deliver your documents right to you.",
  },
];

export default function HowItWorks() {
  return (
    <section id="how-it-works" className="bg-navy-950 px-5 py-20 sm:px-8 sm:py-28">
      <div className="mx-auto max-w-6xl">
        <div className="mx-auto max-w-2xl text-center">
          <span className="inline-block rounded-full bg-white/10 px-4 py-1.5 text-xs font-bold uppercase tracking-wider text-gold-400">
            The process
          </span>
          <h2 className="mt-4 text-3xl font-extrabold tracking-tight text-white sm:text-4xl">
            How It Works
          </h2>
          <p className="mt-3 text-white/60">
            From form to doorstep — four simple steps and you're done.
          </p>
        </div>

        {/* Desktop horizontal */}
        <div className="mt-16 hidden lg:block">
          <div className="relative grid grid-cols-4 gap-6">
            <div className="absolute left-0 right-0 top-8 h-0.5 bg-gradient-to-r from-royal-600 via-gold-400 to-royal-600" />
            {STEPS.map(({ icon: Icon, title, desc }, i) => (
              <div key={title} className="relative flex flex-col items-center text-center">
                <div className="relative z-10 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-royal-500 to-royal-700 text-white shadow-lg shadow-royal-600/30 ring-4 ring-navy-950">
                  <Icon size={26} />
                </div>
                <div className="mt-2 text-xs font-bold text-gold-400">STEP {i + 1}</div>
                <h3 className="mt-1 text-lg font-extrabold text-white">{title}</h3>
                <p className="mt-1.5 max-w-[220px] text-sm text-white/60">{desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Mobile vertical timeline */}
        <div className="mt-12 space-y-8 lg:hidden">
          {STEPS.map(({ icon: Icon, title, desc }, i) => (
            <div key={title} className="flex gap-4">
              <div className="flex flex-col items-center">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-royal-500 to-royal-700 text-white shadow-md">
                  <Icon size={20} />
                </div>
                {i < STEPS.length - 1 && <div className="mt-2 w-0.5 flex-1 bg-white/15" />}
              </div>
              <div className="pb-2">
                <div className="text-xs font-bold text-gold-400">STEP {i + 1}</div>
                <h3 className="mt-0.5 text-base font-extrabold text-white">{title}</h3>
                <p className="mt-1 text-sm text-white/60">{desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
