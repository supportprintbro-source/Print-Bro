import { X } from "lucide-react";
import { CONFIG } from "../lib/config";

interface Props {
  onClose: () => void;
}

export default function PrivacyModal({ onClose }: Props) {
  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center bg-navy-950/60 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="max-h-[80vh] w-full max-w-lg overflow-y-auto rounded-3xl bg-white p-7 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between">
          <h3 className="text-xl font-extrabold text-navy-900">Privacy Policy</h3>
          <button
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-full text-navy-700/50 hover:bg-navy-950/5"
          >
            <X size={18} />
          </button>
        </div>

        <div className="mt-5 space-y-4 text-sm leading-relaxed text-navy-700/80">
          <p>
            PrintBro collects only the information needed to process your printing order: your
            name, mobile number, email address, delivery address, and the document file you
            choose to upload.
          </p>
          <p>
            Uploaded documents are used solely for fulfilling your print order and are never
            shared publicly. Files are not exposed through public URLs — access is restricted to
            authorised PrintBro staff processing your order.
          </p>
          <p>
            Customer information is not sold, rented, or shared with third parties, and is only
            used to communicate with you about your order (e.g. via WhatsApp or email).
          </p>
          <p>
            You may request deletion of your order data and uploaded files at any time by
            contacting{" "}
            <a href={`mailto:${CONFIG.supportEmail}`} className="font-semibold text-royal-600">
              {CONFIG.supportEmail}
            </a>
            .
          </p>
          <p className="text-xs text-navy-700/50">
            This is a summary policy for demonstration purposes and should be reviewed by legal
            counsel before commercial launch.
          </p>
        </div>
      </div>
    </div>
  );
}
