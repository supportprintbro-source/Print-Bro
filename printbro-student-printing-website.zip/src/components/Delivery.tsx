import { Truck, Clock, ShieldCheck } from "lucide-react";
import { CONFIG } from "../lib/config";

export default function Delivery() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-royal-600 to-navy-950 px-5 py-20 sm:px-8 sm:py-24">
      <div className="pointer-events-none absolute -right-20 -top-20 h-72 w-72 rounded-full bg-gold-400/10 blur-3xl" />
      <div className="mx-auto max-w-5xl">
        <div className="grid grid-cols-1 items-center gap-10 lg:grid-cols-[auto_1fr]">
          <div className="mx-auto flex h-28 w-28 items-center justify-center rounded-3xl bg-white/10 backdrop-blur-sm sm:h-32 sm:w-32">
            <Truck size={56} className="text-gold-400" />
          </div>
          <div className="text-center lg:text-left">
            <h2 className="text-3xl font-extrabold tracking-tight text-white sm:text-4xl">
              We Print &amp; Deliver to You!
            </h2>
            <p className="mt-3 text-lg font-medium text-gold-400">
              Convenient. Hassle-free. On time.
            </p>
            <p className="mx-auto mt-4 max-w-2xl text-sm leading-relaxed text-white/70 lg:mx-0">
              {CONFIG.deliveryNote}
            </p>

            <div className="mt-6 flex flex-col justify-center gap-3 sm:flex-row lg:justify-start">
              <div className="flex items-center gap-2 rounded-full bg-white/10 px-4 py-2 text-xs font-semibold text-white">
                <Clock size={14} className="text-gold-400" />
                Fast turnaround
              </div>
              <div className="flex items-center gap-2 rounded-full bg-white/10 px-4 py-2 text-xs font-semibold text-white">
                <ShieldCheck size={14} className="text-gold-400" />
                Safe handling of your files
              </div>
              <div className="flex items-center gap-2 rounded-full bg-white/10 px-4 py-2 text-xs font-semibold text-white">
                <Truck size={14} className="text-gold-400" />
                Campus-friendly drop-off
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
