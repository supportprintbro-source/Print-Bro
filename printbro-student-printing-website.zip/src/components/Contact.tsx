import { Mail, MessageCircle, ArrowRight } from "lucide-react";
import { CONFIG } from "../lib/config";

export default function Contact() {
  return (
    <section id="contact" className="bg-navy-950 px-5 py-20 sm:px-8 sm:py-28">
      <div className="mx-auto max-w-4xl rounded-3xl bg-gradient-to-br from-navy-900 to-royal-700 p-8 text-center shadow-2xl sm:p-14">
        <h2 className="text-3xl font-extrabold tracking-tight text-white sm:text-4xl">
          Get in Touch
        </h2>
        <p className="mt-3 text-white/70">
          Questions about your order, pricing or delivery? We're one message away.
        </p>

        <div className="mt-4 flex items-center justify-center gap-2 text-lg font-bold text-gold-400">
          <Mail size={18} />
          <a href={`mailto:${CONFIG.supportEmail}`} className="hover:underline">
            {CONFIG.supportEmail}
          </a>
        </div>

        <div className="mt-8 flex flex-col justify-center gap-4 sm:flex-row">
          <a
            href={`https://wa.me/${CONFIG.whatsappNumber}`}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center justify-center gap-2 rounded-full bg-[#25D366] px-6 py-3.5 text-sm font-bold text-white shadow-lg transition-all hover:-translate-y-0.5"
          >
            <MessageCircle size={18} />
            Chat on WhatsApp
          </a>
          <a
            href={`mailto:${CONFIG.supportEmail}`}
            className="inline-flex items-center justify-center gap-2 rounded-full bg-white/10 px-6 py-3.5 text-sm font-bold text-white backdrop-blur-sm transition-all hover:-translate-y-0.5 hover:bg-white/20"
          >
            <Mail size={18} />
            Send an Email
          </a>
          <a
            href="#order"
            className="inline-flex items-center justify-center gap-2 rounded-full bg-gold-400 px-6 py-3.5 text-sm font-bold text-navy-950 shadow-lg shadow-gold-400/30 transition-all hover:-translate-y-0.5 hover:bg-gold-300"
          >
            Order Now
            <ArrowRight size={16} />
          </a>
        </div>
      </div>
    </section>
  );
}
