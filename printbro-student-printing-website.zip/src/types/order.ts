// ---------------------------------------------------------------------------
// Shared domain types for PrintBro orders.
//
// These types are intentionally framework-agnostic so the same shapes can be
// reused by:
//   - the customer-facing order form (this app)
//   - a future admin dashboard
//   - a Supabase `orders` table (see lib/supabaseClient.ts)
// ---------------------------------------------------------------------------

export type PrintType = "bw-single" | "bw-double" | "color-single";

export const PRINT_TYPE_LABELS: Record<PrintType, string> = {
  "bw-single": "Black & White — Single Sided",
  "bw-double": "Black & White — Both Sides",
  "color-single": "Full Colour — Single Sided",
};

/**
 * Full order lifecycle. Kept as a flat union so an admin dashboard can
 * render a simple status stepper / filter dropdown.
 */
export type OrderStatus =
  | "Pending"
  | "Confirmed"
  | "Printing"
  | "Ready"
  | "Delivered"
  | "Cancelled";

export const ORDER_STATUSES: OrderStatus[] = [
  "Pending",
  "Confirmed",
  "Printing",
  "Ready",
  "Delivered",
  "Cancelled",
];

export interface OrderFileMeta {
  name: string;
  sizeKB: number;
  type: string;
}

export interface Order {
  id: string; // e.g. PB-2026-0001
  createdAt: string; // ISO timestamp
  customerName: string;
  mobile: string;
  email: string;
  address: string;
  printType: PrintType;
  pages: number;
  copies: number;
  notes?: string;
  file?: OrderFileMeta;
  ratePerPage: number;
  estimatedTotal: number;
  status: OrderStatus;
}
