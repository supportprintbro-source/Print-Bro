/**
 * Generates a human-friendly, sequential order ID like `PB-2026-0001`.
 *
 * NOTE: This uses localStorage as a lightweight demo sequence generator so
 * the site works fully client-side. In production, this should be replaced
 * by a server-side / Supabase sequence (e.g. a Postgres SEQUENCE or a
 * `orders_count` row) to guarantee uniqueness across all customers.
 */
export function generateOrderId(): string {
  const year = new Date().getFullYear();
  const storageKey = `printbro_order_seq_${year}`;

  let nextSeq = 1;
  try {
    const stored = window.localStorage.getItem(storageKey);
    nextSeq = stored ? parseInt(stored, 10) + 1 : 1;
    window.localStorage.setItem(storageKey, String(nextSeq));
  } catch {
    // localStorage unavailable (e.g. private browsing) — fall back to
    // a timestamp-based sequence so the app still works.
    nextSeq = Number(String(Date.now()).slice(-4));
  }

  return `PB-${year}-${String(nextSeq).padStart(4, "0")}`;
}
