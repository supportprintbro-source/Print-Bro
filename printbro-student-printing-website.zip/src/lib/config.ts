// ---------------------------------------------------------------------------
// PrintBro — global configuration
// ---------------------------------------------------------------------------
// Centralising these values makes it easy to update business-critical
// settings (WhatsApp number, delivery zones, pricing, etc.) without hunting
// through components. Replace the placeholder values below with real data
// before going live.
// ---------------------------------------------------------------------------

export const CONFIG = {
  /**
   * WhatsApp number used for order confirmations.
   * Format: country code + number, digits only (no "+", spaces or dashes).
   * TODO: Replace with PrintBro's real WhatsApp Business number.
   */
  whatsappNumber: "8801XXXXXXXXX",

  /** Public support email shown across the site. */
  supportEmail: "support.printbro@gmail.com",

  /** Canonical website URL (used for SEO tags & share links). */
  websiteUrl: "https://supportprintbro-source.github.io/PrintBro/",

  /** Maximum accepted upload size, in megabytes. */
  maxFileSizeMB: 20,

  /** Accepted document extensions for print orders. */
  allowedFileTypes: [".pdf", ".doc", ".docx", ".ppt", ".pptx"],

  /**
   * Delivery is currently manual / zone-dependent.
   * TODO: Replace with real zones + charges once finalised.
   */
  deliveryNote:
    "Delivery availability and charges depend on your location and will be confirmed on WhatsApp before printing begins.",

  /** Placeholder flag — flip on once a payment gateway is integrated. */
  paymentGatewayEnabled: false,
} as const;
