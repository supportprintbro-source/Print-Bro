// ---------------------------------------------------------------------------
// Supabase client — READY FOR FUTURE INTEGRATION
// ---------------------------------------------------------------------------
// The current build is a static, client-only demo so it can be hosted on
// GitHub Pages / Vercel with zero backend setup. The moment PrintBro is
// ready to go live with real orders, this file is where the wiring happens:
//
//   1. Create a Supabase project.
//   2. Add `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` to your env.
//   3. Uncomment the client below.
//   4. Create tables:
//        orders (id, created_at, customer_name, mobile, email, address,
//                print_type, pages, copies, notes, rate_per_page,
//                estimated_total, status, file_path)
//        (RLS enabled — customers can only insert/read their own order by id)
//   5. Create a private Storage bucket `order-files` (NOT public). Generate
//      signed URLs server-side only for staff/admin use.
//   6. Replace the local `submitOrder()` logic in OrderForm with a call to
//      `supabase.from('orders').insert(...)` and
//      `supabase.storage.from('order-files').upload(...)`.
//
// Keeping this scaffold in place means the admin dashboard described in the
// spec can be built against the same `Order` type without changing the
// customer-facing UI.
// ---------------------------------------------------------------------------

// import { createClient } from "@supabase/supabase-js";
//
// const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string | undefined;
// const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as
//   | string
//   | undefined;
//
// export const supabase =
//   supabaseUrl && supabaseAnonKey
//     ? createClient(supabaseUrl, supabaseAnonKey)
//     : null;

export const isSupabaseConfigured = false;
