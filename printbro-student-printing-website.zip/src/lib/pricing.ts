import type { PrintType } from "../types/order";

/**
 * Returns the per-page rate (in BDT) for a given print type and document
 * length. Bulk pricing kicks in once the document itself is over 100 pages.
 */
export function getRatePerPage(type: PrintType, pages: number): number {
  switch (type) {
    case "bw-single":
      return pages > 100 ? 2.5 : 3;
    case "bw-double":
      return pages > 100 ? 3 : 4;
    case "color-single":
      return 4;
    default:
      return 0;
  }
}

export interface PriceEstimate {
  ratePerPage: number;
  totalPrintedPages: number;
  total: number;
}

/**
 * Calculates the estimated order total.
 * Total = rate/page * pages * copies
 */
export function calculateEstimate(
  type: PrintType,
  pages: number,
  copies: number
): PriceEstimate {
  const safePages = Number.isFinite(pages) && pages > 0 ? Math.floor(pages) : 0;
  const safeCopies = Number.isFinite(copies) && copies > 0 ? Math.floor(copies) : 0;
  const ratePerPage = getRatePerPage(type, safePages);
  const totalPrintedPages = safePages * safeCopies;
  const total = Math.round(ratePerPage * totalPrintedPages * 100) / 100;

  return { ratePerPage, totalPrintedPages, total };
}

export function formatBDT(amount: number): string {
  return `৳${amount.toLocaleString("en-BD", {
    minimumFractionDigits: amount % 1 === 0 ? 0 : 2,
    maximumFractionDigits: 2,
  })}`;
}
