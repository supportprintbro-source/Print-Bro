import { CONFIG } from "./config";

export interface FileValidationResult {
  valid: boolean;
  error?: string;
}

/**
 * Client-side file validation. This is a first line of defence for UX only —
 * the same checks (type, size, magic-byte sniffing, antivirus scanning if
 * desired) MUST be re-run server-side (e.g. in a Supabase Edge Function)
 * before a file is persisted to storage, since client checks can be bypassed.
 */
export function validateFile(file: File): FileValidationResult {
  const lowerName = file.name.toLowerCase();
  const hasAllowedExtension = CONFIG.allowedFileTypes.some((ext) =>
    lowerName.endsWith(ext)
  );

  if (!hasAllowedExtension) {
    return {
      valid: false,
      error: `Unsupported file type. Please upload: ${CONFIG.allowedFileTypes.join(", ")}`,
    };
  }

  const maxBytes = CONFIG.maxFileSizeMB * 1024 * 1024;
  if (file.size > maxBytes) {
    return {
      valid: false,
      error: `File is too large. Maximum allowed size is ${CONFIG.maxFileSizeMB}MB.`,
    };
  }

  if (file.size === 0) {
    return { valid: false, error: "This file appears to be empty." };
  }

  return { valid: true };
}

export function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}
